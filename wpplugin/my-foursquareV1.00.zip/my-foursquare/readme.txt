=== My Foursquare ===
Contributors: myfoursquare
Tags: foursquare, four square, four, square, badges, mayors, mayorships, checkin, check in, check-in, place, venue, location, location-based, lbs, gps, mapping, sidebar, widget, gowalla
Requires at least: 2.6
Tested up to: 3.0
Stable tag: trunk

== Description ==
My Foursquare makes it easy to show off your Foursquare badges and mayorships on your Wordpress blog. My Foursquare is also available as a Facebook app and an embed code so you can use it on any website.

My Foursquare will show up as a widget in your Wordpress sidebar. You can customise the widget to display your badges, mayorships, and your last checkin venue. You also customise the appearance of the widget so it fits in with your blog.

More info here: [http://myfoursquare.net/wordpress](http://myfoursquare.net "")

== Installation ==
* Download the plugin from the Wordpress plugin directory: [http://wordpress.org/extend/plugins/my-foursquare/](http://wordpress.org/extend/plugins/my-foursquare/ "")
* Go to your Wordpress dashboard. Choose Add New plugin, then Upload the plugin .zip. Click install now, then Activate.
* Go to your dashboard and select Appearances/Widgets. Locate the My Foursquare widget, drag it into your sidebar, and enter your Foursquare email and password.
* Customize the widget appearance by adjusting the widget settings in the Settings box. 
* That's it. You're done! Note: By installing the plugin you agree that a small 'Powered by My Foursquare' link will be shown at the bottom of the widget.

== Frequently Asked Questions ==
= Where can I get more info? =
[http://myfoursquare.net/wordpress](http://myfoursquare.net/wordpress "")

= Where can I make a feature request? =
[http://myfoursquare.net/wordpress](http://myfoursquare.net/wordpress "")
Click the "feedback" tab on right hand side of page.

= Where can I get support? =
[http://myfoursquare.net/wordpress](http://myfoursquare.net/wordpress "")

== Screenshots ==
* See [http://myfoursquare.net/wordpress](http://myfoursquare.net/wordpress "")

== Changelog ==
* See [http://myfoursquare.net/wordpress](http://myfoursquare.net/wordpress "")

== Upgrade Notice ==
= 1.01 = This is the initial install.